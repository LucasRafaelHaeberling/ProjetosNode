import { Estoque } from "../Estoque.js";
import { Produto } from "../Produto.js";
import { ProdutoPerecivel } from "../ProdutoPerecivel.js";

// Criando o primeiro Objeto
const estoque = new Estoque();

document.addEventListener('DOMContentLoaded', () => {
    atualizarListaProdutos(estoque);

    const btnAdicionar = document.getElementById('adicionarProdutoBtn');
    btnAdicionar.addEventListener('click', () => {
        const nome = document.getElementById('nome').value;
        const preco = parseFloat(document.getElementById('preco').value);
        const quantidade = parseFloat(document.getElementById('quantidade').value);
        const dataValidade = document.getElementById('dataValidade').value;

        let produto;
        if(dataValidade){
            produto = new ProdutoPerecivel(Date.now(), nome, preco, quantidade, dataValidade);
        }else{
            produto = new Produto(Date.now(), nome, preco, quantidade);
        }
        estoque.adicionarProduto(produto);
        mostrarMensagem('Produto adicionado com sucesso!');
        atualizarListaProdutos(estoque);
        document.getElementById('produtoForm').reset();
    })
});

function atualizarListaProdutos(estoque){
    const produtosListados = document.getElementById('produtosListados');
    produtosListados.innerHTML = '';
    estoque.produtos.forEach(produto => {
        const item = document.createElement('a');
        item.setAttribute('class', 'list-group-item list-group-item-action');
        item.textContent = produto.descricao();
        produtosListados.appendChild(item);
    });
}

function mostrarMensagem(texto, tipo = 'success'){
    const mensagemDiv = document.createElement('div');
    mensagemDiv.className = `alert alert-${tipo} mt-3`;
    mensagemDiv.textContent = texto;
    document.querySelector('.container').prepend(mensagemDiv);
    setTimeout(() => {
        mensagemDiv.remove();
    }, 3000);
}